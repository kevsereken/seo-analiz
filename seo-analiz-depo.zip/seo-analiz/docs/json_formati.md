# Ortak JSON Formatı (sürüm 0.1 – taslak)

Tarama modülü (Kevser) her site için **tek bir JSON dosyası** üretir.
Anahtar kelime (Akif), YZ (Firdevs), değerlendirme (Sema) ve arayüz (Beyza)
modülleri bu dosyayı okur. Alan adları değişecekse önce ekipte konuşulur ve
`format_surumu` artırılır.

Dosya adı: `veri/ham/<alan_adi>_<YYYYMMDD>.json` (ör. `veri/ham/ornek.com.tr_20261015.json`)

## Kurallar

- Bir alan henüz doldurulmuyorsa silinmez, değeri `null` olur.
- Metinler UTF-8 kaydedilir (`ensure_ascii=False`), Türkçe karakterler bozulmaz.
- Tarihler ISO 8601 formatında: `2026-10-15T14:30:00+03:00`.
- Uzunluklar karakter sayısıdır.

## Site düzeyi

| Alan | Tür | Açıklama | Hafta |
|---|---|---|---|
| `format_surumu` | metin | Şu an `"0.1"` | 4 |
| `site` | metin | Başlangıç URL'si | 4 |
| `taranma_zamani` | metin | Taramanın başladığı an | 4 |
| `robots_txt` | nesne / null | `{"var_mi": bool, "engellenen_yollar": [..]}` | 5 |
| `sitemap` | liste / null | Sitemap'te bulunan URL'ler | 5 |
| `core_web_vitals` | nesne / null | PageSpeed: `{"lcp_ms", "inp_ms", "cls", "performans_puani"}` | 6 |
| `sayfalar` | liste | Her sayfa için aşağıdaki nesne | 4 |

## Sayfa düzeyi (`sayfalar[]`)

| Alan | Tür | Açıklama | Hafta |
|---|---|---|---|
| `url` | metin | İstenen URL | 4 |
| `son_url` | metin | Yönlendirme sonrası URL | 4 |
| `durum_kodu` | sayı | HTTP durum kodu (200, 301, 404…) | 4 |
| `https` | bool | Son URL https mi | 4 |
| `dil` | metin / null | `<html lang>` değeri | 4 |
| `title` | nesne | `{"metin": str/null, "uzunluk": int}` | 4 |
| `meta_description` | nesne | `{"metin": str/null, "uzunluk": int}` | 4 |
| `basliklar` | nesne | `{"h1": [..], "h2": [..], … "h6": [..]}` | 4 (H1), 5 (H2–H6) |
| `canonical` | metin / null | Canonical URL | 5 |
| `robots_meta` | metin / null | ör. `"index, follow"` | 5 |
| `viewport` | bool / null | Viewport meta etiketi var mı | 5 |
| `linkler` | nesne / null | `{"ic": [..], "dis": [..], "kirik": [{"url", "durum_kodu"}]}` | 5 |
| `gorseller` | liste / null | `[{"src": str, "alt": str/null}]` | 5 |
| `schema_org` | liste / null | Bulunan schema türleri, ör. `["Organization", "Product"]` | 5 |
| `open_graph` | nesne / null | `{"og:title": .., "og:image": ..}` | 5 |
| `metin` | metin / null | Görünür sayfa metni (Akif'in anahtar kelime çıkarımı için) | 5 |
| `kelime_sayisi` | sayı / null | `metin` içindeki kelime sayısı | 5 |
| `hata` | metin / null | Sayfa alınamadıysa hata mesajı | 4 |

Tam bir örnek: `ornek_cikti/ornek_site.json`.

## Toplantıda karar verilecekler

1. Alan adları Türkçe mi kalsın, İngilizce mi olsun? (Taslakta Türkçe.)
2. `metin` alanı tam metin mi olsun, yoksa ilk N kelime mi? (Dosya boyutunu etkiler.)
3. Akif'in ve Firdevs'in çıktıları için de benzer bir format gerekiyor mu, yoksa ayrı dosyalar mı olsun?
4. Sayfa limiti: 30 mu, 50 mi?
