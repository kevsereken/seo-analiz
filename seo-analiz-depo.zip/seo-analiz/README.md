# Yapay Zekâ Destekli SEO Analiz Aracı

Bir web sitesini tarayan, teknik SEO ve anahtar kelime analizi yapan, yerel bir
büyük dil modeliyle (Ollama üzerinde Qwen ve Hermes) öneriler ve düzeltilmiş
HTML üreten araç. Türk web siteleri üzerinde test edilir.

## Ekip ve modüller

| Kişi | Modül | Klasör |
|---|---|---|
| Kevser | Tarama + koordinasyon | `src/tarama/` |
| Akif | Anahtar kelime + Türkçe NLP | `src/anahtar_kelime/` |
| Firdevs | Yapay zekâ katmanı | `src/yz/` |
| Sema | Test, puanlama, veri analizi | `src/degerlendirme/` |
| Beyza | Arayüz + rapor | `src/arayuz/` |

## Veri akışı

```
tarama  ──JSON──▶  anahtar_kelime  ──▶  yz  ──▶  degerlendirme
   └─────────────────────────────────────────────▶  arayuz
```

Modüller arasındaki ortak format: [`docs/json_formati.md`](docs/json_formati.md)

## Kurulum

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate    macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

## Çalıştırma

```bash
python -m src.tarama.tarayici https://www.ornek.com.tr
python -m pytest tests/
```

## Kullanılan modeller

| Model | Ollama adı | Not |
|---|---|---|
| Qwen 2.5 7B | `qwen2.5:7b` | Ana model |
| Hermes 3 8B (Nous Research) | `hermes3:8b` | Karşılaştırma modeli |

## Çalışma kuralları

- Herkes kendi klasöründe çalışır; başkasının klasöründe değişiklik yapacaksan önce haber ver.
- `main` dalına doğrudan yazma yerine kendi dalını aç (`kevser/tarama` gibi), bitince birleştir.
- JSON formatını değiştirmeden önce ekipte konuş; `docs/json_formati.md` dosyasını güncelle.
- Ham tarama çıktıları (`veri/ham/`) depoya girmez; paylaşılacak örnekler `ornek_cikti/` klasörüne konur.
