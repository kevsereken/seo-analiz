"""
Tarama modülü – iskelet (4. hafta)

Tek bir sayfayı indirir; title, meta description ve H1 başlıklarını çıkarır
ve sonucu ortak JSON formatında (docs/json_formati.md) kaydeder.

Kullanım:
    python -m src.tarama.tarayici https://www.ornek.com.tr
    python -m src.tarama.tarayici https://www.ornek.com.tr -o veri/ham/ornek.json

Sonraki haftalarda eklenecekler:
    5. hafta: H2–H6, canonical, robots meta, linkler, görseller, schema, OG,
              robots.txt ve sitemap.xml
    6. hafta: çok sayfalı tarama + sayfa limiti, PageSpeed API, hata yönetimi
"""

import argparse
import json
from datetime import datetime, timezone, timedelta
from pathlib import Path
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup

FORMAT_SURUMU = "0.1"
TURKIYE_SAATI = timezone(timedelta(hours=3))

# Bazı siteler varsayılan Python isteğini engelliyor; kendimizi tanıtıyoruz.
ISTEK_BASLIKLARI = {
    "User-Agent": "SEO-Analiz-Ogrenci-Projesi/0.1 (+egitim amacli)",
    "Accept-Language": "tr-TR,tr;q=0.9",
}
ZAMAN_ASIMI = 15  # saniye


def simdi() -> str:
    return datetime.now(TURKIYE_SAATI).isoformat(timespec="seconds")


def metin_ve_uzunluk(metin):
    """Boşlukları temizler; {"metin", "uzunluk"} nesnesi döndürür."""
    if metin is None:
        return {"metin": None, "uzunluk": 0}
    temiz = " ".join(metin.split())
    return {"metin": temiz or None, "uzunluk": len(temiz)}


def html_ayristir(html: str) -> dict:
    """HTML içinden 4. haftanın alanlarını çıkarır (ağ bağlantısı gerekmez)."""
    soup = BeautifulSoup(html, "html.parser")

    title_etiketi = soup.find("title")
    title = title_etiketi.get_text() if title_etiketi else None

    meta = soup.find("meta", attrs={"name": lambda d: d and d.lower() == "description"})
    meta_aciklama = meta.get("content") if meta else None

    html_etiketi = soup.find("html")
    dil = html_etiketi.get("lang") if html_etiketi else None

    h1_listesi = [" ".join(h.get_text().split()) for h in soup.find_all("h1")]

    return {
        "dil": dil,
        "title": metin_ve_uzunluk(title),
        "meta_description": metin_ve_uzunluk(meta_aciklama),
        "basliklar": {"h1": h1_listesi, "h2": None, "h3": None,
                      "h4": None, "h5": None, "h6": None},
    }


def bos_sayfa(url: str) -> dict:
    """Formatın tüm alanlarını null ile oluşturur; sonra doldurulur."""
    return {
        "url": url, "son_url": None, "durum_kodu": None, "https": None,
        "dil": None,
        "title": {"metin": None, "uzunluk": 0},
        "meta_description": {"metin": None, "uzunluk": 0},
        "basliklar": {"h1": [], "h2": None, "h3": None,
                      "h4": None, "h5": None, "h6": None},
        "canonical": None, "robots_meta": None, "viewport": None,
        "linkler": None, "gorseller": None, "schema_org": None,
        "open_graph": None, "metin": None, "kelime_sayisi": None,
        "hata": None,
    }


def sayfa_tara(url: str) -> dict:
    """Tek bir sayfayı indirir ve sayfa nesnesini döndürür."""
    sayfa = bos_sayfa(url)
    try:
        yanit = requests.get(url, headers=ISTEK_BASLIKLARI,
                             timeout=ZAMAN_ASIMI, allow_redirects=True)
    except requests.RequestException as hata:
        sayfa["hata"] = f"{type(hata).__name__}: {hata}"
        return sayfa

    sayfa["son_url"] = yanit.url
    sayfa["durum_kodu"] = yanit.status_code
    sayfa["https"] = urlparse(yanit.url).scheme == "https"

    # Türkçe karakterlerin bozulmaması için kodlamayı içerikten tahmin et
    if yanit.encoding is None or yanit.encoding.lower() == "iso-8859-1":
        yanit.encoding = yanit.apparent_encoding

    if "text/html" in yanit.headers.get("Content-Type", ""):
        sayfa.update(html_ayristir(yanit.text))
    else:
        sayfa["hata"] = f"HTML değil: {yanit.headers.get('Content-Type')}"
    return sayfa


def site_tara(baslangic_url: str) -> dict:
    """Şimdilik yalnızca başlangıç sayfasını tarar (çok sayfa: 6. hafta)."""
    return {
        "format_surumu": FORMAT_SURUMU,
        "site": baslangic_url,
        "taranma_zamani": simdi(),
        "robots_txt": None,
        "sitemap": None,
        "core_web_vitals": None,
        "sayfalar": [sayfa_tara(baslangic_url)],
    }


def kaydet(sonuc: dict, yol: Path) -> None:
    yol.parent.mkdir(parents=True, exist_ok=True)
    yol.write_text(json.dumps(sonuc, ensure_ascii=False, indent=2), encoding="utf-8")


def varsayilan_dosya_yolu(url: str) -> Path:
    alan = urlparse(url).netloc.replace("www.", "") or "site"
    tarih = datetime.now(TURKIYE_SAATI).strftime("%Y%m%d")
    return Path("veri/ham") / f"{alan}_{tarih}.json"


def main():
    ayrac = argparse.ArgumentParser(description="Tek sayfa SEO tarayıcısı")
    ayrac.add_argument("url", help="Taranacak sayfanın adresi (https://...)")
    ayrac.add_argument("-o", "--cikti", help="JSON dosyasının yolu")
    arg = ayrac.parse_args()

    sonuc = site_tara(arg.url)
    yol = Path(arg.cikti) if arg.cikti else varsayilan_dosya_yolu(arg.url)
    kaydet(sonuc, yol)

    s = sonuc["sayfalar"][0]
    print(f"Kaydedildi: {yol}")
    print(f"  Durum kodu : {s['durum_kodu']}")
    print(f"  Title      : {s['title']['metin']} ({s['title']['uzunluk']} karakter)")
    print(f"  Meta desc. : {s['meta_description']['uzunluk']} karakter")
    print(f"  H1 sayısı  : {len(s['basliklar']['h1'])}")
    if s["hata"]:
        print(f"  HATA       : {s['hata']}")


if __name__ == "__main__":
    main()
