"""Çalıştırma: python -m pytest tests/  (internet gerekmez)"""
from src.tarama.tarayici import html_ayristir

ORNEK_HTML = """<!doctype html>
<html lang="tr"><head>
  <title>  Ayakkabı Modelleri | Örnek Mağaza </title>
  <meta name="Description" content="En şık ayakkabılar uygun fiyatlarla.">
</head><body>
  <h1>Kadın Ayakkabı</h1>
  <h1> Yeni   Sezon </h1>
</body></html>"""


def test_title_ve_meta():
    s = html_ayristir(ORNEK_HTML)
    assert s["title"]["metin"] == "Ayakkabı Modelleri | Örnek Mağaza"
    assert s["title"]["uzunluk"] == len("Ayakkabı Modelleri | Örnek Mağaza")
    assert s["meta_description"]["metin"] == "En şık ayakkabılar uygun fiyatlarla."
    assert s["dil"] == "tr"


def test_birden_fazla_h1():
    s = html_ayristir(ORNEK_HTML)
    assert s["basliklar"]["h1"] == ["Kadın Ayakkabı", "Yeni Sezon"]


def test_eksik_etiketler():
    s = html_ayristir("<html><body><p>boş</p></body></html>")
    assert s["title"] == {"metin": None, "uzunluk": 0}
    assert s["meta_description"]["metin"] is None
    assert s["basliklar"]["h1"] == []
